# Granja
Proyecto de Lenguaje III
---
### PAN Empezamos arreglando el git pero ya tenemos el login solo falta modificarlo un poco
### PAN kike avances 28/12/2024

### PAN kike avances 01/01/2025
### PAN kike avances 03/01/2025
### Uff cagado hasta la madre login listo "" y home"" 16/01/2025

